**To delete an OU**

The following example shows how to delete an OU. The example assumes that you previously removed all accounts and other OUs from the OU: ::

	aws organizations delete-organizational-unit --organizational-unit-id ou-examplerootid111-exampleouid111
