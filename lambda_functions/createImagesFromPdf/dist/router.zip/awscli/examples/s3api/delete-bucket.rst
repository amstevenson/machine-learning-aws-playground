The following command deletes a bucket named ``my-bucket``::

  aws s3api delete-bucket --bucket my-bucket --region us-east-1
